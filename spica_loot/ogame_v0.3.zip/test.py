a={}
a['a']='1'
a['b']='2'
a['c']='3'
a['d']='4'
print len(a)


for l in a:
	print l
print '---------------------'

def test(i):
	l = 0
	for a_ in a:
		if l <= i:
			current = a_
		l += 1
	return current



for i in range(0,len(a)):
	print i,'----'
	print 'current',test(i)