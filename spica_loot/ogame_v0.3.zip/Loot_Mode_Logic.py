from PyQt4.QtCore import *
import Web_Analyze_Tools

def Open_Note_Page(self):
	self.open_url = 'https://s150-en.ogame.gameforge.com/game/index.php?page=notices&id=367&show=1&popup=0'
	self.load(QUrl(self.open_url))

def Get_Note_Text(self):
	self.note_text = Web_Analyze_Tools.Get_Target_Notices_Text(self.current_html)