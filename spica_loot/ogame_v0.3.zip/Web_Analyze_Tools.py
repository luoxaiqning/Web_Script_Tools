import re
import Initialize_logic

def Get_Planet_List(html):
	html = html.replace(" ","").replace("\n","").replace("\t","")
	for planets in re.compile(r'id="planet-.*?</a>').findall(html):
		name   = re.compile(r'planet-name">[^<]*').search(planets).group().replace('planet-name">','')
		id_    = re.compile(r'id="planet-\d*').search(planets).group().replace('id="planet-','')
		koords = re.compile(r'planet-koords">[^<]*').search(planets).group().replace('planet-koords">','')
		Initialize_logic.Global_.planet_id[name] 	 = id_
		Initialize_logic.Global_.planet_koords[name] = koords
	return True

def Get_Planet_Resources(html,text):
	text = text.replace(" ","")
	html = html.replace(" ","").replace("\n","").replace("\t","").replace(".","").replace("\"","")
	res_number = re.compile(text+'.*?</span>').search(html).group()
	res_number = re.compile(r'\d\d*|-\d\d*').search(res_number).group()
	return res_number

def Get_Planet_Building_Level(html,text):
	text = text.replace(" ","")
	html = html.replace(" ","").replace("\n","").replace("\t","").replace(".","").replace("\"","")
	building_level = re.compile(text+'</span>\d.*?</a>').search(html)
	if building_level:
		building_level = re.compile(r'\d\d*').search(building_level.group()).group()
		return building_level
	return 'In construction'

def Get_Planet_In_Construction(html):
	html = html.replace("\n","").replace("\t","").replace(".","").replace("\"","")
	in_construction = re.compile(r'Nobuildingsinconstruction').search(html)
	if in_construction:
		return 'No buildings in construction'
	in_construction = re.compile(r'Cancelexpansionof.*?\d+').search(html).group().replace("Cancelexpansionof","")
	return in_construction

def Get_Building_Upgrade_Url(html,text):
	text = text.replace(" ","")
	html = html.replace(" ","").replace("\n","").replace("\t","").replace("\'","")
	Building_type = re.compile('title="'+text+'.*?'+text).search(html).group()
	Building_type = re.compile(r'\d+').search(Building_type).group()
	Building_Upgrade_Url = re.compile(r'sendBuildRequest\(https://s150-en\.ogame\.gameforge\.com/game/index\.php\?page=(resources|station)&modus=1&type='+str(Building_type)+'.*?<imgsrc').search(html)
	if Building_Upgrade_Url:
		Building_Upgrade_Url = re.compile(r'https.*,null').search(Building_Upgrade_Url.group()).group().replace(",null","")
		return Building_Upgrade_Url
	else:
		return False

def Get_Planet_Fleet(html,text):
	text = text.replace(" ","")
	html = html.replace(" ","").replace("\n","").replace("\t","").replace("\'","")
	number = re.compile(r'<spanclass="textlabel">'+text+'.*?</a>|title="'+text+'.*?\)').search(html).group()
	number = re.compile(r'\d\d*').search(number).group()
	return number

def Get_Planet_Defense(html,text):
	text = text.replace(" ","")
	html = html.replace(" ","").replace("\n","").replace("\t","").replace("\'","")
	number = re.compile(r'<spanclass="textlabel">'+text+'.*?</a>|title="'+text+'.*?\)').search(html).group()
	number = re.compile(r'\d\d*').search(number).group()
	return number

def Get_Planet_In_Production(html,text):
	number = 0
	in_queue = 0
	text = text.replace(" ","")
	html = html.replace(" ","").replace("\n","").replace("\t","").replace("\'","")
	try:
		in_production = re.compile(r'Productionof.*?'+text+'inprogress').search(html).group()
		in_production = int(re.compile(r'\d\d*').search(in_production).group())
	except:
		in_production = 0
	try:
		in_queue_list = re.compile(r'Productionqueue.*<!--ENDCONTENTAREA-->').search(html).group()
		in_queue_list = re.compile(r'title=".*?'+text).findall(in_queue_list)
		for queue in in_queue_list:
			in_queue = in_queue + int(re.compile(r'\d\d*').search(queue).group())
	except:
		in_queue = 0
	number = in_production + in_queue
	return number

def Get_Data(html):
	data = re.compile(r'\d+').search(html).group()
	return data

def Get_Match(html,text):
	if re.compile(text).search(html):
		return True
	return False

def Get_Token(html):
	html = html.replace(" ","").replace("\n","").replace("\t","").replace("\'","")
	token = re.compile(r'tokenvalue=.*?/>').search(html).group()
	token = token.replace("tokenvalue=","").replace("/>","")
	return token

def Get_Target_Notices_Text(html):
	html = html.replace(" ","").replace("\n","").replace("\t","").replace("\'","")
	text = re.compile(r'data-max-length="5000"data-value=".*?"').search(html).group()
	text = text.replace("data-max-length=\"5000\"data-value=\"","").replace("\"","")
	target_list = {}
	target_list['Current Target'] = re.compile(r'current_target:.*?,').search(text).group().replace("current_target:","").replace(",","")
	text = re.compile(r'\d.*?,').findall(text)
	for int_ in range(1,len(text)):
		target_list[int_] = text[int_].replace(",","")
	return target_list

def Get_Target_Deatils(target):
	target = re.compile(r'\d\d*').findall(target)
	target_deatils={}
	target_deatils['Galaxy'] 	= target[0]
	target_deatils['System'] 	= target[1]
	target_deatils['Position'] 	= target[2]
	target_deatils['Resources'] = target[3]
	target_deatils['Defense'] 	= target[4]
	return target_deatils
html = '<textarea cols="120" rows="20" class="textBox text" name="noticeText" tabindex="3"\
                      data-max-length="5000"\
                      data-value="current_target:2,1-123-1-10000-0,1-123-2-2131231-0,1-123-3-12312-123123,"\
                    >aszdvjxhbcvkjbnkdlf'
'''
target_list = Get_Target_Notices_Text(html)
for int_ in range(1,len(target_list)):
	print Get_Target_Deatils(target_list[int_])
'''